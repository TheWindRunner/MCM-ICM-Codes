function question5_1(year_information)
year=year_information(:,1);
year_characteristic=year_information(:,2:end);
figure;
subplot(611)
plot(year,year_characteristic(:,1))
title('danceability change over time')
subplot(612)
plot(year,year_characteristic(:,2))
title('energy change over time')
subplot(613)
plot(year,year_characteristic(:,3))
title('valence change over time')
subplot(614)
plot(year,year_characteristic(:,4))
title('tempo change over time')
subplot(615)
plot(year,year_characteristic(:,5))
title('loudness change over time')
subplot(616)
plot(year,year_characteristic(:,7))
title('key change over time')
figure;
subplot(611)
plot(year,year_characteristic(:,8))
title('acousticness change over time')
subplot(612)
plot(year,year_characteristic(:,9))
title('instrumentalness change over time')
subplot(613)
plot(year,year_characteristic(:,10))
title('liveness change over time')
subplot(614)
plot(year,year_characteristic(:,11))
title('speechiness change over time')
subplot(615)
plot(year,year_characteristic(:,12))
title('duration/ms change over time')
subplot(616)
plot(year,year_characteristic(:,13))
title('popularity change over time')


















