tic
clear
clc
close all
format long
B1=xlsread('influence_data.csv');
[~,B2]=xlsread('influence_data.csv');
influencer_id=B1(:,1);
follower_id=B1(:,5);
[~,genre_number]=xlsread('main_genre_number.xlsx');
influencer_genre=B2(2:length(B2),3);
follower_genre=B2(2:length(B2),7);
influencer_genre_number=zeros(1,length(B1));
follower_genre_number=zeros(1,length(B1));
for ii=1:length(B1)
    influencer_genre_number(ii)=find(strcmp(genre_number,influencer_genre(ii)));
    follower_genre_number(ii)=find(strcmp(genre_number,follower_genre(ii)));
end
musician_information=xlsread('musician_information.xlsx');
music_information=xlsread('music_information.xlsx');
year_information=xlsread('year_information.csv');
genre_information=xlsread('genre_information.csv');
B=setdiff(follower_id,musician_information(:,1));
num=find(follower_id==B);
follower_genre_number(num)=[]; 
follower_id(num)=[]; 
influencer_genre_number(num)=[]; 
influencer_id(num)=[]; 

clear influencer_genre follower_genre B1 B2 ii num B
%follower_genre_number ׷�������ɴ���
%follower_id ׷���ߴ���
%influencer_genre_number Ӱ�������ɴ���
%influencer_id Ӱ���ߴ���
%genre_number ��������
%musician_information ���ּ���Ϣ
%music_information ������Ϣ
%year_information�����Ϣ

[near,near1]=question1(influencer_id,influencer_genre_number,follower_id,follower_genre_number,1:20);

similarity_matrix=question2(musician_information,genre_number);

question3(musician_information,genre_number)

similarity_information=question4(influencer_id,follower_id,musician_information,similarity_matrix,near);

question5_1(year_information)
year=1945:1955;
impact_music=question5_2(music_information,year,year_information);

toc
