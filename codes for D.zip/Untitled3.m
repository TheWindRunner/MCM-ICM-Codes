

bg=digraph(near);
impact_artist=zeros(50,1);
for ii=1:50
    son=successors(bg,mmm(ii));
    if(size(son)==[0 1])
        impact_artist(ii)=0;
        continue;
    end
    for jj=1:length(son)
        if(jj==1)
            grandson=successors(bg,son(1));
        else
            grandson=[grandson;successors(bg,son(jj))];
        end
    end
    grandson=unique(grandson);
    grandson=setdiff(grandson,son);
    impact_artist(ii)=2*length(son)+length(grandson);
end
impact_artist=50+5*log(impact_artist+1);


