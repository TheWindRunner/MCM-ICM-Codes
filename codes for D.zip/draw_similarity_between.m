function draw_similarity_between(similarity_matrix,musician_information,genre_number)
figure;
a=6;
b=9;
num1=find(musician_information(:,16)==a);
num2=find(musician_information(:,16)==b);
genre_number_similarity=zeros(1,length(num1));
w=zeros(1,length(num2));
for ii=1:length(num1)
    for jj=1:length(num2)
        if(ii==jj)
            continue;
        end
        ww=abs(musician_information(ii,17)-musician_information(jj,17))/200;
        w(jj)=1-ww;
        genre_number_similarity(ii)=genre_number_similarity(ii)+similarity_matrix(num1(ii),num2(jj))*w(jj);
    end
    genre_number_similarity(ii)=genre_number_similarity(ii)/sum(w);
end
subplot(221)
histogram(genre_number_similarity)
xlabel('similarity(%)')
ylabel('amount')
title(['similarity between ' genre_number(a) ' and ' genre_number(b)])
a=20;
b=9;
num1=find(musician_information(:,16)==a);
num2=find(musician_information(:,16)==b);
genre_number_similarity=zeros(1,length(num1));
w=zeros(1,length(num2));
for ii=1:length(num1)
    for jj=1:length(num2)
        if(ii==jj)
            continue;
        end
        ww=abs(musician_information(ii,17)-musician_information(jj,17))/200;
        w(jj)=1-ww;
        genre_number_similarity(ii)=genre_number_similarity(ii)+similarity_matrix(num1(ii),num2(jj))*w(jj);
    end
    genre_number_similarity(ii)=genre_number_similarity(ii)/sum(w);
end
subplot(222)
histogram(genre_number_similarity)
xlabel('similarity(%)')
ylabel('amount')
title(['similarity between ' genre_number(a) ' and ' genre_number(b)])
a=5;
b=7;
num1=find(musician_information(:,16)==a);
num2=find(musician_information(:,16)==b);
genre_number_similarity=zeros(1,length(num1));
w=zeros(1,length(num2));
for ii=1:length(num1)
    for jj=1:length(num2)
        if(ii==jj)
            continue;
        end
        ww=abs(musician_information(ii,17)-musician_information(jj,17))/200;
        w(jj)=1-ww;
        genre_number_similarity(ii)=genre_number_similarity(ii)+similarity_matrix(num1(ii),num2(jj))*w(jj);
    end
    genre_number_similarity(ii)=genre_number_similarity(ii)/sum(w);
end
subplot(223)
histogram(genre_number_similarity)
xlabel('similarity(%)')
ylabel('amount')
title(['similarity between ' genre_number(a) ' and ' genre_number(b)])
a=8;
b=7;
num1=find(musician_information(:,16)==a);
num2=find(musician_information(:,16)==b);
genre_number_similarity=zeros(1,length(num1));
w=zeros(1,length(num2));
for ii=1:length(num1)
    for jj=1:length(num2)
        if(ii==jj)
            continue;
        end
        ww=abs(musician_information(ii,17)-musician_information(jj,17))/200;
        w(jj)=1-ww;
        genre_number_similarity(ii)=genre_number_similarity(ii)+similarity_matrix(num1(ii),num2(jj))*w(jj);
    end
    genre_number_similarity(ii)=genre_number_similarity(ii)/sum(w);
end
subplot(224)
histogram(genre_number_similarity)
xlabel('similarity(%)')
ylabel('amount')
title(['similarity between ' genre_number(a) ' and ' genre_number(b)])

