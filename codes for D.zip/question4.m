function similarity_information=question4(influencer_id,follower_id,musician_information,similarity_matrix,near)
ww=1;
for ii=1:length(near)
    for jj=1:length(near)
        if(near(ii,jj)==1)&&(near(jj,ii)==1)
           w(ww,1)=ii;
           w(ww,2)=jj;
           ww=ww+1;
        end
    end
end
mm=zeros(1,length(influencer_id));
for ii=1:length(mm)
    mm(ii)=similarity_matrix(find(musician_information(:,1)==influencer_id(ii)),find(musician_information(:,1)==follower_id(ii)));
end
hole_similarity=mean(mean(similarity_matrix));
if_similarity=mean(mm);
nn=zeros(1,length(w));
for ii=1:length(w)
    nn(ii)=similarity_matrix(w(ii,1),w(ii,2));
end
mutual_similarity=mean(nn);
similarity_information=zeros(3,14);
similarity_information(:,1)=[hole_similarity,if_similarity,mutual_similarity];
num=length(musician_information(:,1));

tic
danceability_similarity_matrix=zeros(num,num);
for ii=1:num
    for jj=ii:num
        if(jj==ii)
            danceability_similarity_matrix(ii,jj)=100;
        else
            danceability_similarity_matrix(ii,jj)=similarity_count(musician_information(ii,:),musician_information(jj,:),'danceability');
            danceability_similarity_matrix(jj,ii)=danceability_similarity_matrix(ii,jj);
        end
    end
end
mm=zeros(1,length(influencer_id));
for ii=1:length(mm)
    mm(ii)=danceability_similarity_matrix(find(musician_information(:,1)==influencer_id(ii)),find(musician_information(:,1)==follower_id(ii)));
end
danceability_hole_similarity=mean(mean(danceability_similarity_matrix));
danceability_if_similarity=mean(mm);
nn=zeros(1,length(w));
for ii=1:length(w)
    nn(ii)=danceability_similarity_matrix(w(ii,1),w(ii,2));
end
danceability_mutual_similarity=mean(nn);
similarity_information(:,2)=[danceability_hole_similarity,danceability_if_similarity,danceability_mutual_similarity];
toc
energy_similarity_matrix=zeros(num,num);
for ii=1:num
    for jj=ii:num
        if(jj==ii)
            energy_similarity_matrix(ii,jj)=100;
        else
            energy_similarity_matrix(ii,jj)=similarity_count(musician_information(ii,:),musician_information(jj,:),'energy');
            energy_similarity_matrix(jj,ii)=energy_similarity_matrix(ii,jj);
        end
    end
end
mm=zeros(1,length(influencer_id));
for ii=1:length(mm)
    mm(ii)=energy_similarity_matrix(find(musician_information(:,1)==influencer_id(ii)),find(musician_information(:,1)==follower_id(ii)));
end
energy_hole_similarity=mean(mean(energy_similarity_matrix));
energy_if_similarity=mean(mm);
nn=zeros(1,length(w));
for ii=1:length(w)
    nn(ii)=energy_similarity_matrix(w(ii,1),w(ii,2));
end
energy_mutual_similarity=mean(nn);
similarity_information(:,3)=[energy_hole_similarity,energy_if_similarity,energy_mutual_similarity];
valence_similarity_matrix=zeros(num,num);
for ii=1:num
    for jj=ii:num
        if(jj==ii)
            valence_similarity_matrix(ii,jj)=100;
        else
            valence_similarity_matrix(ii,jj)=similarity_count(musician_information(ii,:),musician_information(jj,:),'valence');
            valence_similarity_matrix(jj,ii)=valence_similarity_matrix(ii,jj);
        end
    end
end
mm=zeros(1,length(influencer_id));
for ii=1:length(mm)
    mm(ii)=valence_similarity_matrix(find(musician_information(:,1)==influencer_id(ii)),find(musician_information(:,1)==follower_id(ii)));
end
valence_hole_similarity=mean(mean(valence_similarity_matrix));
valence_if_similarity=mean(mm);
nn=zeros(1,length(w));
for ii=1:length(nn)
    nn(ii)=valence_similarity_matrix(w(ii,1),w(ii,2));
end
valence_mutual_similarity=mean(nn);
similarity_information(:,4)=[valence_hole_similarity,valence_if_similarity,valence_mutual_similarity];
tempo_similarity_matrix=zeros(num,num);
for ii=1:num
    for jj=ii:num
        if(jj==ii)
            tempo_similarity_matrix(ii,jj)=100;
        else
            tempo_similarity_matrix(ii,jj)=similarity_count(musician_information(ii,:),musician_information(jj,:),'tempo');
            tempo_similarity_matrix(jj,ii)=tempo_similarity_matrix(ii,jj);
        end
    end
end
mm=zeros(1,length(influencer_id));
for ii=1:length(mm)
    mm(ii)=tempo_similarity_matrix(find(musician_information(:,1)==influencer_id(ii)),find(musician_information(:,1)==follower_id(ii)));
end
tempo_hole_similarity=mean(mean(tempo_similarity_matrix));
tempo_if_similarity=mean(mm);
nn=zeros(1,length(w));
for ii=1:length(nn)
    nn(ii)=tempo_similarity_matrix(w(ii,1),w(ii,2));
end
tempo_mutual_similarity=mean(nn);
similarity_information(:,5)=[tempo_hole_similarity,tempo_if_similarity,tempo_mutual_similarity];
loudness_similarity_matrix=zeros(num,num);
for ii=1:num
    for jj=ii:num
        if(jj==ii)
            loudness_similarity_matrix(ii,jj)=100;
        else
            loudness_similarity_matrix(ii,jj)=similarity_count(musician_information(ii,:),musician_information(jj,:),'loudness');
            loudness_similarity_matrix(jj,ii)=loudness_similarity_matrix(ii,jj);
        end
    end
end
mm=zeros(1,length(influencer_id));
for ii=1:length(mm)
    mm(ii)=loudness_similarity_matrix(find(musician_information(:,1)==influencer_id(ii)),find(musician_information(:,1)==follower_id(ii)));
end
loudness_hole_similarity=mean(mean(loudness_similarity_matrix));
loudness_if_similarity=mean(mm);
nn=zeros(1,length(w));
for ii=1:length(nn)
    nn(ii)=loudness_similarity_matrix(w(ii,1),w(ii,2));
end
loudness_mutual_similarity=mean(nn);
similarity_information(:,6)=[loudness_hole_similarity,loudness_if_similarity,loudness_mutual_similarity];
mode_similarity_matrix=zeros(num,num);
for ii=1:num
    for jj=ii:num
        if(jj==ii)
            mode_similarity_matrix(ii,jj)=100;
        else
            mode_similarity_matrix(ii,jj)=similarity_count(musician_information(ii,:),musician_information(jj,:),'mode');
            mode_similarity_matrix(jj,ii)=mode_similarity_matrix(ii,jj);
        end
    end
end
mm=zeros(1,length(influencer_id));
for ii=1:length(mm)
    mm(ii)=mode_similarity_matrix(find(musician_information(:,1)==influencer_id(ii)),find(musician_information(:,1)==follower_id(ii)));
end
mode_hole_similarity=mean(mean(mode_similarity_matrix));
mode_if_similarity=mean(mm);
nn=zeros(1,length(w));
for ii=1:length(nn)
    nn(ii)=mode_similarity_matrix(w(ii,1),w(ii,2));
end
mode_mutual_similarity=mean(nn);
similarity_information(:,7)=[mode_hole_similarity,mode_if_similarity,mode_mutual_similarity];
key_similarity_matrix=zeros(num,num);
for ii=1:num
    for jj=ii:num
        if(jj==ii)
            key_similarity_matrix(ii,jj)=100;
        else
            key_similarity_matrix(ii,jj)=similarity_count(musician_information(ii,:),musician_information(jj,:),'key');
            key_similarity_matrix(jj,ii)=key_similarity_matrix(ii,jj);
        end
    end
end
mm=zeros(1,length(influencer_id));
for ii=1:length(mm)
    mm(ii)=key_similarity_matrix(find(musician_information(:,1)==influencer_id(ii)),find(musician_information(:,1)==follower_id(ii)));
end
key_hole_similarity=mean(mean(key_similarity_matrix));
key_if_similarity=mean(mm);
nn=zeros(1,length(w));
for ii=1:length(nn)
    nn(ii)=key_similarity_matrix(w(ii,1),w(ii,2));
end
key_mutual_similarity=mean(nn);
similarity_information(:,8)=[key_hole_similarity,key_if_similarity,key_mutual_similarity];
acousticness_similarity_matrix=zeros(num,num);
for ii=1:num
    for jj=ii:num
        if(jj==ii)
            acousticness_similarity_matrix(ii,jj)=100;
        else
            acousticness_similarity_matrix(ii,jj)=similarity_count(musician_information(ii,:),musician_information(jj,:),'acousticness');
            acousticness_similarity_matrix(jj,ii)=acousticness_similarity_matrix(ii,jj);
        end
    end
end
mm=zeros(1,length(influencer_id));
for ii=1:length(mm)
    mm(ii)=acousticness_similarity_matrix(find(musician_information(:,1)==influencer_id(ii)),find(musician_information(:,1)==follower_id(ii)));
end
acousticness_hole_similarity=mean(mean(acousticness_similarity_matrix));
acousticness_if_similarity=mean(mm);
nn=zeros(1,length(w));
for ii=1:length(nn)
    nn(ii)=acousticness_similarity_matrix(w(ii,1),w(ii,2));
end
acousticness_mutual_similarity=mean(nn);
similarity_information(:,9)=[acousticness_hole_similarity,acousticness_if_similarity,acousticness_mutual_similarity];
instrumentalness_similarity_matrix=zeros(num,num);
for ii=1:num
    for jj=ii:num
        if(jj==ii)
            instrumentalness_similarity_matrix(ii,jj)=100;
        else
            instrumentalness_similarity_matrix(ii,jj)=similarity_count(musician_information(ii,:),musician_information(jj,:),'instrumentalness');
            instrumentalness_similarity_matrix(jj,ii)=instrumentalness_similarity_matrix(ii,jj);
        end
    end
end
mm=zeros(1,length(influencer_id));
for ii=1:length(mm)
    mm(ii)=instrumentalness_similarity_matrix(find(musician_information(:,1)==influencer_id(ii)),find(musician_information(:,1)==follower_id(ii)));
end
instrumentalness_hole_similarity=mean(mean(instrumentalness_similarity_matrix));
instrumentalness_if_similarity=mean(mm);
nn=zeros(1,length(w));
for ii=1:length(nn)
    nn(ii)=instrumentalness_similarity_matrix(w(ii,1),w(ii,2));
end
instrumentalness_mutual_similarity=mean(nn);
similarity_information(:,10)=[instrumentalness_hole_similarity,instrumentalness_if_similarity,instrumentalness_mutual_similarity];
liveness_similarity_matrix=zeros(num,num);
for ii=1:num
    for jj=ii:num
        if(jj==ii)
            liveness_similarity_matrix(ii,jj)=100;
        else
            liveness_similarity_matrix(ii,jj)=similarity_count(musician_information(ii,:),musician_information(jj,:),'liveness');
            liveness_similarity_matrix(jj,ii)=liveness_similarity_matrix(ii,jj);
        end
    end
end
mm=zeros(1,length(influencer_id));
for ii=1:length(mm)
    mm(ii)=liveness_similarity_matrix(find(musician_information(:,1)==influencer_id(ii)),find(musician_information(:,1)==follower_id(ii)));
end
liveness_hole_similarity=mean(mean(liveness_similarity_matrix));
liveness_if_similarity=mean(mm);
nn=zeros(1,length(w));
for ii=1:length(nn)
    nn(ii)=liveness_similarity_matrix(w(ii,1),w(ii,2));
end
liveness_mutual_similarity=mean(nn);
similarity_information(:,11)=[liveness_hole_similarity,liveness_if_similarity,liveness_mutual_similarity];
speechiness_similarity_matrix=zeros(num,num);
for ii=1:num
    for jj=ii:num
        if(jj==ii)
            speechiness_similarity_matrix(ii,jj)=100;
        else
            speechiness_similarity_matrix(ii,jj)=similarity_count(musician_information(ii,:),musician_information(jj,:),'speechiness');
            speechiness_similarity_matrix(jj,ii)=speechiness_similarity_matrix(ii,jj);
        end
    end
end
mm=zeros(1,length(influencer_id));
for ii=1:length(mm)
    mm(ii)=speechiness_similarity_matrix(find(musician_information(:,1)==influencer_id(ii)),find(musician_information(:,1)==follower_id(ii)));
end
speechiness_hole_similarity=mean(mean(speechiness_similarity_matrix));
speechiness_if_similarity=mean(mm);
nn=zeros(1,length(w));
for ii=1:length(nn)
    nn(ii)=speechiness_similarity_matrix(w(ii,1),w(ii,2));
end
speechiness_mutual_similarity=mean(nn);
similarity_information(:,12)=[speechiness_hole_similarity,speechiness_if_similarity,speechiness_mutual_similarity];
duration_ms_similarity_matrix=zeros(num,num);
for ii=1:num
    for jj=ii:num
        if(jj==ii)
            duration_ms_similarity_matrix(ii,jj)=100;
        else
            duration_ms_similarity_matrix(ii,jj)=similarity_count(musician_information(ii,:),musician_information(jj,:),'duration_ms');
            duration_ms_similarity_matrix(jj,ii)=duration_ms_similarity_matrix(ii,jj);
        end
    end
end
mm=zeros(1,length(influencer_id));
for ii=1:length(mm)
    mm(ii)=duration_ms_similarity_matrix(find(musician_information(:,1)==influencer_id(ii)),find(musician_information(:,1)==follower_id(ii)));
end
duration_ms_hole_similarity=mean(mean(duration_ms_similarity_matrix));
duration_ms_if_similarity=mean(mm);
nn=zeros(1,length(w));
for ii=1:length(nn)
    nn(ii)=duration_ms_similarity_matrix(w(ii,1),w(ii,2));
end
duration_ms_mutual_similarity=mean(nn);
similarity_information(:,13)=[duration_ms_hole_similarity,duration_ms_if_similarity,duration_ms_mutual_similarity];
genre_similarity_matrix=zeros(num,num);
for ii=1:num
    for jj=ii:num
        if(jj==ii)
            genre_similarity_matrix(ii,jj)=100;
        else
            genre_similarity_matrix(ii,jj)=similarity_count(musician_information(ii,:),musician_information(jj,:),'genre');
            genre_similarity_matrix(jj,ii)=genre_similarity_matrix(ii,jj);
        end
    end
end
mm=zeros(1,length(influencer_id));
for ii=1:length(nn)
    mm(ii)=genre_similarity_matrix(find(musician_information(:,1)==influencer_id(ii)),find(musician_information(:,1)==follower_id(ii)));
end
genre_hole_similarity=mean(mean(genre_similarity_matrix));
genre_if_similarity=mean(mm);
nn=zeros(1,length(w));
for ii=1:length(w)
    nn(ii)=genre_similarity_matrix(w(ii,1),w(ii,2));
end
genre_mutual_similarity=mean(nn);
similarity_information(:,14)=[genre_hole_similarity,genre_if_similarity,genre_mutual_similarity];

