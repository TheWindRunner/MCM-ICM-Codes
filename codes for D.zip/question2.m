function similarity_matrix=question2(musician_information,genre_number)
%this is used to solve question 2
num=length(musician_information(:,1));
similarity_matrix=zeros(num,num);
for ii=1:num
    for jj=ii:num
        if(jj==ii)
            similarity_matrix(ii,jj)=100;
        else
            similarity_matrix(ii,jj)=similarity_count(musician_information(ii,:),musician_information(jj,:),'all');
            similarity_matrix(jj,ii)=similarity_matrix(ii,jj);
        end
    end
end

draw_similarity_in(similarity_matrix,musician_information,genre_number)
draw_similarity_out(similarity_matrix,musician_information,genre_number)
draw_similarity_between(similarity_matrix,musician_information,genre_number)









