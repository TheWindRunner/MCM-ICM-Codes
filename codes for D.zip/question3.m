function question3(musician_information,genre_number)
year=unique(musician_information(:,17));
for kk=1:20
    num=find(musician_information(:,16)==kk);
    genre_characteristic=musician_information(num,[2 3 4 9 10 11 12 13 17]);
    genre_characteristic_year=zeros(length(genre_characteristic(1,:)),length(year));
    for ii=1:length(year)
        w=0;
        for mm=1:length(genre_characteristic(:,end))        
            if(genre_characteristic(mm,end)==year(ii))
                w=1;
            end
        end
        if(~w)
            if(ii==1)
                genre_characteristic_year(:,ii)=mean(genre_characteristic)';
                continue;
            else
                genre_characteristic_year(:,ii)=genre_characteristic_year(:,ii-1);
                continue;
            end
        end
        for jj=1:length(genre_characteristic(1,:))
            genre_characteristic_year(jj,ii)=mean(genre_characteristic(find(genre_characteristic(:,end)==year(ii)),jj));
        end
    end
    genre_characteristic_year(end-1,:)=genre_characteristic_year(end-1,:)/60000;
    figure;
    for ii=1:length(genre_characteristic(1,:))-1
        plot(year,genre_characteristic_year(ii,:))
        hold on
    end
    hold off
    legend('danceability',	'energy'	,'valence'		,'acousticness'	,'instrumentalness'	,'liveness'	,'speechiness'	,'duration/min')
    title(['genre of ',genre_number(kk)])

end

    
    
    
    
    
    
    
    
    
    
