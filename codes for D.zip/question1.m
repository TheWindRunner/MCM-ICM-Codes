function [near,near1]=question1(influencer_id,influencer_genre_number,follower_id,follower_genre_number,genre_number)
%this is used to solve question 1 and draw some pictures;
%near�����ּ�֮ǰ���ڽӾ���near1������֮����ڽӾ���
nn=[influencer_id,follower_id];
mm=unique(nn);
near=zeros(length(mm),length(mm));
for ii=1:length(influencer_id)
    if(influencer_genre_number(ii)==follower_genre_number(ii))
        ww=1;
    else
        ww=1;
    end
    near(find(mm==influencer_id(ii)),find(mm==follower_id(ii)))=ww;
end
near1=zeros(length(genre_number),length(genre_number));
for ii=1:length(influencer_id)
    if(influencer_genre_number(ii)==follower_genre_number(ii))
        continue;
    else
           near1(find(genre_number==influencer_genre_number(ii)),find(genre_number==follower_genre_number(ii)))=near1(find(genre_number==influencer_genre_number(ii)),find(genre_number==follower_genre_number(ii)))+1;
    end
end

draw_digraph(near,near1);
%������ͼ

        