function draw_similarity_out(similarity_matrix,musician_information,genre_number)
figure;
kk=6;
num=find(musician_information(:,16)==kk);
num1=setdiff(1:length(musician_information(:,16)),num);
genre_number_similarity=zeros(1,length(num));
w=zeros(1,length(num));
for ii=1:length(num)
    for jj=1:length(num1)
        if(ii==jj)
            continue;
        end
        ww=abs(musician_information(ii,15)-musician_information(jj,15))/200;
        w(jj)=1-ww;
        genre_number_similarity(ii)=genre_number_similarity(ii)+similarity_matrix(num(ii),num1(jj))*w(jj);
    end
    genre_number_similarity(ii)=genre_number_similarity(ii)/sum(w);
end
subplot(221)
histogram(genre_number_similarity)
title(['similarity out ',genre_number(kk)])
xlabel('similarity(%)')
ylabel('amount')
kk=11;
num=find(musician_information(:,16)==kk);
num1=setdiff(1:length(musician_information(:,16)),num);
genre_number_similarity=zeros(1,length(num));
w=zeros(1,length(num));
for ii=1:length(num)
    for jj=1:length(num1)
        if(ii==jj)
            continue;
        end
        ww=abs(musician_information(ii,15)-musician_information(jj,15))/200;
        w(jj)=1-ww;
        genre_number_similarity(ii)=genre_number_similarity(ii)+similarity_matrix(num(ii),num1(jj))*w(jj);
    end
    genre_number_similarity(ii)=genre_number_similarity(ii)/sum(w);
end
subplot(222)
histogram(genre_number_similarity)
title(['similarity out ',genre_number(kk)])
xlabel('similarity(%)')
ylabel('amount')
kk=12;
num=find(musician_information(:,16)==kk);
num1=setdiff(1:length(musician_information(:,16)),num);
genre_number_similarity=zeros(1,length(num));
w=zeros(1,length(num));
for ii=1:length(num)
    for jj=1:length(num1)
        if(ii==jj)
            continue;
        end
        ww=abs(musician_information(ii,15)-musician_information(jj,15))/200;
        w(jj)=1-ww;
        genre_number_similarity(ii)=genre_number_similarity(ii)+similarity_matrix(num(ii),num1(jj))*w(jj);
    end
    genre_number_similarity(ii)=genre_number_similarity(ii)/sum(w);
end
subplot(223)
histogram(genre_number_similarity)
title(['similarity out ',genre_number(kk)])
xlabel('similarity(%)')
ylabel('amount')
kk=15;
num=find(musician_information(:,16)==kk);
num1=setdiff(1:length(musician_information(:,16)),num);
genre_number_similarity=zeros(1,length(num));
w=zeros(1,length(num));
for ii=1:length(num)
    for jj=1:length(num1)
        if(ii==jj)
            continue;
        end
        ww=abs(musician_information(ii,15)-musician_information(jj,15))/200;
        w(jj)=1-ww;
        genre_number_similarity(ii)=genre_number_similarity(ii)+similarity_matrix(num(ii),num1(jj))*w(jj);
    end
    genre_number_similarity(ii)=genre_number_similarity(ii)/sum(w);
end
subplot(224)
histogram(genre_number_similarity)
title(['similarity out ',genre_number(kk)])
xlabel('similarity(%)')
ylabel('amount')