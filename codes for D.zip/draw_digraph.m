function draw_digraph(near,near1)

dg=digraph(near);
genre_influnce_dg=sum(near,2);
genre_influnce_dg=5*genre_influnce_dg/max(genre_influnce_dg)+1;
figure;
H=plot(dg);
% Dg.Edges.Weight=log(dg.Edges.Weight+1);
% dgwidths=5*Dg.Edges.Weight/max(Dg.Edges.Weight);
% H.LineWidth=dgwidths;
H.MarkerSize=genre_influnce_dg;
% H.EdgeLabel=dg.Edges.Weight;

genre_influnce_bg=sum(near1,2);
genre_influnce_bg=log(1+genre_influnce_bg);
bg=digraph(near1);
figure;
P=plot(bg);
Bg.Edges.Weight=log(bg.Edges.Weight+1);
bgwidths=5*Bg.Edges.Weight/max(Bg.Edges.Weight);
P.LineWidth=bgwidths;
P.MarkerSize=genre_influnce_bg;
% P.EdgeLabel=bg.Edges.Weight;


