function draw_similarity_in(similarity_matrix,musician_information,genre_number)
figure;
kk=6;
num=find(musician_information(:,16)==kk);
genre_number_similarity=zeros(1,length(num));
w=zeros(1,length(num));
for ii=1:length(num)
    for jj=1:length(num)
        if(ii==jj)
            continue;
        end
        ww=abs(musician_information(ii,15)-musician_information(jj,15))/200;
        w(jj)=1-ww;
        genre_number_similarity(ii)=genre_number_similarity(ii)+similarity_matrix(num(ii),num(jj))*w(jj);
    end
    genre_number_similarity(ii)=genre_number_similarity(ii)/sum(w);
end
subplot(221)
histogram(genre_number_similarity)
title(['similarity in ',genre_number(kk)])
xlabel('similarity(%)')
ylabel('amount')
kk=11;
num=find(musician_information(:,16)==kk);
genre_number_similarity=zeros(1,length(num));
w=zeros(1,length(num));
for ii=1:length(num)
    for jj=1:length(num)
        if(ii==jj)
            continue;
        end
        ww=abs(musician_information(ii,17)-musician_information(jj,17))/200;
        w(jj)=1-ww;
        genre_number_similarity(ii)=genre_number_similarity(ii)+similarity_matrix(num(ii),num(jj))*w(jj);
    end
    genre_number_similarity(ii)=genre_number_similarity(ii)/sum(w);
end
subplot(222)
histogram(genre_number_similarity)
title(['similarity in ',genre_number(kk)])
xlabel('similarity(%)')
ylabel('amount')
kk=12;
num=find(musician_information(:,16)==kk);
genre_number_similarity=zeros(1,length(num));
w=zeros(1,length(num));
for ii=1:length(num)
    for jj=1:length(num)
        if(ii==jj)
            continue;
        end
        ww=abs(musician_information(ii,17)-musician_information(jj,17))/200;
        w(jj)=1-ww;
        genre_number_similarity(ii)=genre_number_similarity(ii)+similarity_matrix(num(ii),num(jj))*w(jj);
    end
    genre_number_similarity(ii)=genre_number_similarity(ii)/sum(w);
end
subplot(223)
histogram(genre_number_similarity)
title(['similarity in ',genre_number(kk)])
xlabel('similarity(%)')
ylabel('amount')
kk=15;
num=find(musician_information(:,16)==kk);
genre_number_similarity=zeros(1,length(num));
w=zeros(1,length(num));
for ii=1:length(num)
    for jj=1:length(num)
        if(ii==jj)
            continue;
        end
        ww=abs(musician_information(ii,17)-musician_information(jj,17))/200;
        w(jj)=1-ww;
        genre_number_similarity(ii)=genre_number_similarity(ii)+similarity_matrix(num(ii),num(jj))*w(jj);
    end
    genre_number_similarity(ii)=genre_number_similarity(ii)/sum(w);
end
subplot(224)
histogram(genre_number_similarity)
title(['similarity in ',genre_number(kk)])
xlabel('similarity(%)')
ylabel('amount')