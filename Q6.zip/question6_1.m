function question6_1(year_information)
year=year_information(:,1);
year_characteristic=year_information(:,2:end);
figure();
subplot(6,1,1)
for k=1:100
    if(year_characteristic(k,1)~=-1)
       plot(year(k),year_characteristic(k,1),'.','MarkerSize',20);
       hold on;
    end
end
set(gca,'xlim',[1921 2020]);
set(gca,'ylim',[0 1]);
set(gca,'xticklabel',[]);%����ʾx������̶�
set(gca,'box','on');
set(gca,'position',[0.15 0.8 0.75 0.15]); %0.47Ϊ��fig�±߽�ļ��
pos=axis;
ylabel('danceablity','FontSize',15,'Rotation',0,'position',[1910 (pos(3)+pos(4))/2]);
title('Parameters of Music Changes by Year','FontSize',15);

subplot(6,1,2)
for k=1:100
    if(year_characteristic(k,2)~=-1)
       plot(year(k),year_characteristic(k,2),'.','MarkerSize',20);
       hold on;
    end
end
set(gca,'xlim',[1921 2020]);
set(gca,'ylim',[0 1]);
set(gca,'xticklabel',[]);%����ʾx������̶�
set(gca,'box','on');
set(gca,'position',[0.15 0.65 0.75 0.15]); %0.47Ϊ��fig�±߽�ļ��
pos=axis;
ylabel('energy','FontSize',15,'Rotation',0,'position',[1910 (pos(3)+pos(4))/2]);

subplot(6,1,3)
for k=1:100
    if(year_characteristic(k,3)~=-1)
       plot(year(k),year_characteristic(k,3),'.','MarkerSize',20);
       hold on;
    end
end
set(gca,'xlim',[1921 2020]);
set(gca,'ylim',[0 1]);
set(gca,'xticklabel',[]);%����ʾx������̶�
set(gca,'box','on');
set(gca,'position',[0.15 0.5 0.75 0.15]); %0.47Ϊ��fig�±߽�ļ��
pos=axis;
ylabel('valence','FontSize',15,'Rotation',0,'position',[1910 (pos(3)+pos(4))/2]);


subplot(6,1,6)
for k=1:100
    if(year_characteristic(k,7)~=-1)
       plot(year(k),year_characteristic(k,7),'.','MarkerSize',20);
       hold on;
    end
end
set(gca,'xlim',[1921 2020]);
set(gca,'ylim',[-0.8 13]);
%set(gca,'xticklabel',[]);%����ʾx������̶�
set(gca,'box','on');
set(gca,'position',[0.15 0.05 0.75 0.15]); %0.47Ϊ��fig�±߽�ļ��
pos=axis;
ylabel('key','FontSize',15,'Rotation',0,'position',[1910 (pos(3)+pos(4))/2]);
xlabel('Year','FontSize',15,'position',[(pos(1)+pos(2))/2 pos(3)]-1);

subplot(6,1,5)
for k=1:100
    if(year_characteristic(k,5)~=-1)
       plot(year(k),year_characteristic(k,5),'.','MarkerSize',20);
       hold on;
    end
end
set(gca,'xlim',[1921 2020]);
set(gca,'ylim',[-40 0]);
set(gca,'xticklabel',[]);%����ʾx������̶�
set(gca,'box','on');
set(gca,'position',[0.15 0.2 0.75 0.15]); %0.47Ϊ��fig�±߽�ļ��
pos=axis;
ylabel('loudness','FontSize',15,'Rotation',0,'position',[1910 (pos(3)+pos(4))/2]);

subplot(6,1,4)
for k=1:100
    if(year_characteristic(k,4)~=-1)
       plot(year(k),year_characteristic(k,4),'.','MarkerSize',20);
       hold on;
    end
end
set(gca,'xlim',[1921 2020]);
set(gca,'ylim',[90 180]);
set(gca,'xticklabel',[]);%����ʾx������̶�
set(gca,'box','on');
set(gca,'position',[0.15 0.35 0.75 0.15]); %0.47Ϊ��fig�±߽�ļ��
pos=axis;
ylabel('tempo','FontSize',15,'Rotation',0,'position',[1910 (pos(3)+pos(4))/2]);

figure();
subplot(6,1,1)
for k=1:100
    if(year_characteristic(k,8)~=-1)
       plot(year(k),year_characteristic(k,8),'.','MarkerSize',20);
       hold on;
    end
end
set(gca,'xlim',[1921 2020]);
set(gca,'ylim',[0 1]);
set(gca,'xticklabel',[]);%����ʾx������̶�
set(gca,'box','on');
set(gca,'position',[0.15 0.8 0.75 0.15]); %0.47Ϊ��fig�±߽�ļ��
pos=axis;
ylabel('acousticness','FontSize',15,'Rotation',0,'position',[1910 (pos(3)+pos(4))/2]);
title('Parameters of Music Changes by Year','FontSize',15);

subplot(6,1,2)
for k=1:100
    if(year_characteristic(k,9)~=-1)
       plot(year(k),year_characteristic(k,9),'.','MarkerSize',20);
       hold on;
    end
end
set(gca,'xlim',[1921 2020]);
set(gca,'ylim',[0 1]);
set(gca,'xticklabel',[]);%����ʾx������̶�
set(gca,'box','on');
set(gca,'position',[0.15 0.65 0.75 0.15]); %0.47Ϊ��fig�±߽�ļ��
pos=axis;
ylabel('instrumentalness','FontSize',15,'Rotation',0,'position',[1910 (pos(3)+pos(4))/2]);

subplot(6,1,3)
for k=1:100
    if(year_characteristic(k,10)~=-1)
       plot(year(k),year_characteristic(k,10),'.','MarkerSize',20);
       hold on;
    end
end
set(gca,'xlim',[1921 2020]);
set(gca,'ylim',[0 1]);
set(gca,'xticklabel',[]);%����ʾx������̶�
set(gca,'box','on');
set(gca,'position',[0.15 0.5 0.75 0.15]); %0.47Ϊ��fig�±߽�ļ��
pos=axis;
ylabel('liveness','FontSize',15,'Rotation',0,'position',[1910 (pos(3)+pos(4))/2]);

subplot(6,1,6)
for k=1:100
    if(year_characteristic(k,13)~=-1)
       plot(year(k),year_characteristic(k,13),'.','MarkerSize',20);
       hold on;
    end
end
set(gca,'xlim',[1921 2020]);
set(gca,'ylim',[-4 75]);
%set(gca,'xticklabel',[]);%����ʾx������̶�
set(gca,'box','on');
set(gca,'position',[0.15 0.05 0.75 0.15]); %0.47Ϊ��fig�±߽�ļ��
pos=axis;
ylabel('popularity','FontSize',15,'Rotation',0,'position',[1910 (pos(3)+pos(4))/2]);
xlabel('Year','FontSize',15,'position',[(pos(1)+pos(2))/2 pos(3)]-4);

subplot(6,1,5)
for k=1:100
    if(year_characteristic(k,12)~=-1)
       plot(year(k),year_characteristic(k,12)/1000/60,'.','MarkerSize',20);
       hold on;
    end
end
set(gca,'xlim',[1921 2020]);
set(gca,'ylim',[1 15]);
set(gca,'xticklabel',[]);%����ʾx������̶�
set(gca,'box','on');
set(gca,'position',[0.15 0.2 0.75 0.15]); %0.47Ϊ��fig�±߽�ļ��
pos=axis;
ylabel('duration/min','FontSize',15,'Rotation',0,'position',[1910 (pos(3)+pos(4))/2]);


subplot(6,1,4)
for k=1:100
    if(year_characteristic(k,11)~=-1)
       plot(year(k),year_characteristic(k,11),'.','MarkerSize',20);
       hold on;
    end
end
set(gca,'xlim',[1921 2020]);
set(gca,'ylim',[0 1]);
set(gca,'xticklabel',[]);%����ʾx������̶�
set(gca,'box','on');
set(gca,'position',[0.15 0.35 0.75 0.15]); %0.47Ϊ��fig�±߽�ļ��
pos=axis;
ylabel('speechiness','FontSize',15,'Rotation',0,'position',[1910 (pos(3)+pos(4))/2]);
% 
% figure;
% subplot(611)
% plot(year,year_characteristic(:,1))
% set(gca,'xlim',[1921 2020]);
% set(gca,'ylim',[0 1]);
% title('danceability change over time')
% subplot(612)
% plot(year,year_characteristic(:,2))
% set(gca,'xlim',[1921 2020]);
% set(gca,'ylim',[0 1]);
% title('energy change over time')
% subplot(613)
% plot(year,year_characteristic(:,3))
% set(gca,'xlim',[1921 2020]);
% set(gca,'ylim',[0 1]);
% title('valence change over time')
% subplot(614)
% plot(year,year_characteristic(:,4))
% set(gca,'xlim',[1921 2020]);
% set(gca,'ylim',[90 180]);
% title('tempo change over time')
% subplot(615)
% plot(year,year_characteristic(:,5))
% set(gca,'xlim',[1921 2020]);
% set(gca,'ylim',[-40 0]);
% title('loudness change over time')
% subplot(616)
% plot(year,year_characteristic(:,7))
% set(gca,'xlim',[1921 2020]);
% set(gca,'ylim',[-0.8 13]);
% title('key change over time')
% figure;
% subplot(611)
% plot(year,year_characteristic(:,8))
% title('acousticness change over time')
% subplot(612)
% plot(year,year_characteristic(:,9))
% title('instrumentalness change over time')
% subplot(613)
% plot(year,year_characteristic(:,10))
% title('liveness change over time')
% subplot(614)
% plot(year,year_characteristic(:,11))
% title('speechiness change over time')
% subplot(615)
% plot(year,year_characteristic(:,12))
% title('duration/ms change over time')
% subplot(616)
% plot(year,year_characteristic(:,13))
% title('popularity change over time')


















