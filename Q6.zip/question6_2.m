function impact_music=question6_2(music_information,year,genre_number,year_information)
a=music_information(:,15);
num=[];
for ii=1:length(year)
    if(ii==1)
        num=find(a==year(1));
    continue;
    end
    num=[num;find(a==year(ii))];
end
for k=1:length(num)
   if(music_information(num(k),16)~=genre_number);%�Ѳ�������ɱ�ĸ����߳�ȥ
      num(k)=0; 
   end
end
num(find(num==0))=[];

influence_music=music_information(num,:);
influence_year=year_information(find(year_information(:,1)==year(end))+1:end,:);
influence_similarity=zeros(length(num),length(influence_year(:,1)));
for ii=1:length(num)
    for jj=1:length(influence_year(:,1))
    influence_similarity(ii,jj)=influence_similarity_count(influence_music(ii,:),year_information(jj,:),'all');
    end
end
win=tukeywin(1.7*length(influence_year(:,1)));
weight_year=win(1:length(influence_year(:,1)));
% plot(year(end)+1:2020,weight_year)
% xlabel('year')
% ylabel('weight')
% weight_year=1/length(influence_year(:,1)):1/length(influence_year(:,1)):1;
% weight_year=weight_year+1;
impact=zeros(length(num),1);
for ii=1:length(num)
    impact(ii)=sum(influence_similarity(ii,:).*weight_year')/sum(weight_year);
end
impact_music=[influence_music(:,1),impact];
impact_music=sortrows(impact_music,2,'descend');














